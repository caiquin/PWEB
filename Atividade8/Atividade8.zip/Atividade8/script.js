var i = 0;
var sexo;
var nome;
var opiniao;
var idade;
var maior = 0;
var menor = 1000;
var pes = 0;
var per = 0;
var h = 0;
var m = 0;
var bom = 0;
var ot = 0;
var somaIdade = 0;

while(i <= 44){
    idade = parseInt(prompt("Informe sua idade"))
    sexo = prompt("Informe o sexo\nH para homem\nM para mulher")
    opiniao = parseInt(prompt("Informe sua opinião\n1- Péssimo\n2- Regular\n3- Bom\n4- Ótimo"))

    somaIdade = somaIdade + idade;

    if(maior < idade)
        maior = idade;

    if(menor > idade)
        menor = idade;
    
    if(opiniao == 1)
        pes++;

    if(opiniao == 3 || opiniao == 4){
        if(opiniao == 3)
            bom++
        else if(opiniao == 4)
            ot++

        var total = bom + ot;

        total = (total * 100) / 45
    }
    if(sexo == "H")
        h++;
    else if(sexo == "M")
        m++;
    
    i++;
}

var mediaIdade = somaIdade / 45;

alert("Média de idade: " + mediaIdade)
alert("Idade da pessoa mais velha: " + maior)
alert("Idade da pessoa mais nova: " + menor)
alert("Quantidade de pessoas que responderam péssimo: " + pes)
alert("Porcentagem de pessoas que responderam ótimo e bom: " + total + "%")
alert("Número de homens: " + h)
alert("Número de mulheres: " + m)



