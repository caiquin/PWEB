const sql = require('mssql');
 
 module.exports = function (app) {
    
        const config = {
            user: 'BD2221025', //'LOGON',
 
            password: 'cqntngmstvrS10@', //'SENHA',
 
            database: 'LP2', //'site_fatec',
 
            server: 'APOLO', //'NOME_DO_SERVIDOR',
            options: {
                encrypt: false,
                trustServerCertificate: true // se você não tiver um certificado de servidor configurado
            },
           // driver:'msnodesqlv8'
        }

        return sql.connect(config);

    }