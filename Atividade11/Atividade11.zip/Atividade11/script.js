var func1 = new Object();
func1.matricula = "9842179421";
func1.nome = "Marcio da Silva";
func1.funcao = "Pedreiro";

alert("------Fúncionario 1------" + "\nNúmero de Matrícula: " + func1.matricula + "\nNome: " + func1.nome + "\nFunção: " + func1.funcao);

function Funcionario(matricula, nome, funcao){
    this.matricula = matricula;
    this.nome = nome;
    this.funcao = funcao;

    this.MostraDados = function(){
        return "------Fúncionario 2------" + "\nNumero de Matricula: " + this.matricula + "\nNome: " + this.nome + "\nFuncao: " + this.funcao
    }
}

var m = prompt("Digite a matricula do funcionario")
var n = prompt("Digite o nome do funcionario")
var f = prompt("Digite a funcao do funcionario")

var func2 = new Funcionario(m,n,f);

alert(func2.MostraDados());

var func3 = {};
func3.matricula = "8412894"
func3.nome = "Paulo"
func3.funcao = "Engenheiro"

alert(`------Fúncionario 3------
Matricula: ${func3.matricula}
Nome: ${func3.nome} 
Função: ${func3.funcao}`);