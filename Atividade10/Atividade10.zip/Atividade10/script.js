function maiorNumero(n1, n2, n3){
    if(n1 > n2 && n1 > n3)
        return n1;
    else if(n2> n1 && n2 > n3)
        return n2;
    else
        return n3;
}

function ordenar(n1, n2, n3){
    var numeros = [n1, n2, n3];

    numeros.sort(function(a,b){return a - b})

    return numeros;
}

function palindromo(str) {
    str = str.toLowerCase().replace(/\s/g, '');
    
    var reversedStr = str.split('').reverse().join('');
    
    if (str === reversedStr) 
        return true;
    
    else 
        return false;
}

function triangulo(l1, l2, l3){
    if(Math.abs(l2 - l3) < l1 < l2 + l3 && Math.abs(l1 - l3) < l2 < l1 + l3 && Math.abs(l1 - l2) < l3 < l1 + l2){
        if(l1 === l2 && l2 === l3){
            alert("É um Triângulo Equilatero");
        }
        else if(l1 === l2 || l1 === l3 || l2 === l3){
            alert("É um Triângulo Isósceles");
        }
        else{
            alert("É um Triângulo Escaleno")
        } 
    }
    else{
        alert("Não é um triângulo");
    }  
}

do{
    var opcao = parseInt(prompt("Informe qual função deseja executar\n1- Encontrar o maior número\n2- Ordenar números\n3- Verificar palindromo\n4- Tipo de triângulo\n5- Sair"))

    switch(opcao){
        case 1:
            var n1 = parseFloat(prompt("Digite o primero numero"))
            var n2 = parseFloat(prompt("Digite o segundo numero"))
            var n3 = parseFloat(prompt("Digite o terceiro numero"))
    
            var maior = maiorNumero(n1,n2,n3);
            alert("O maior número é: " + maior);
        break;
    
        case 2:
            var num1 = parseFloat(prompt("Digite o primero numero"))
            var num2 = parseFloat(prompt("Digite o segundo numero"))
            var num3 = parseFloat(prompt("Digite o terceiro numero"))
    
            var ordenarnumeros = ordenar(num1,num2,num3);
            alert("Números em ordem crescente: " + ordenarnumeros.join(", "));
        break;
    
        case 3:
            var p = prompt("Digite a palavra a ser testada")
    
            var ehpalindromo = palindromo(p);
            if(ehpalindromo)
                alert("A palavra " + p + " é um palindromo")
            else
                alert("A palavra " + p + " não é um palindromo")
        break;
    
        case 4:
            var lado1 = parseFloat(prompt("Digite o primeiro lado"))
            var lado2 = parseFloat(prompt("Digite o segundo lado"))
            var lado3 = parseFloat(prompt("Digite o terceiro lado"))
    
            var tipotriangulo = triangulo(lado1,lado2,lado3);
    }
    
}while(opcao != 5)

