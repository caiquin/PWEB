function maiusculasMinusculas() {
    var texto = document.getElementById('texto').value;
    var maiusculasCheckbox = document.getElementById('maiusculas');
    var minusculasCheckbox = document.getElementById('minusculas');

    if (maiusculasCheckbox.checked && minusculasCheckbox.checked) {
        alert('Selecione apenas uma opção entre Maiúsculas ou Minúsculas.');
        texto.value = '';
        maiusculasCheckbox.checked = false;
        minusculasCheckbox.checked = false;
        return;
    }
    if(maiusculasCheckbox.checked)
        document.getElementById('texto').value = texto.toUpperCase();
    else if(minusculasCheckbox.checked)
        document.getElementById('texto').value = texto.toLowerCase(); 
}