class Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo) {
        this.nomeCorrentista = nomeCorrentista;
        this.banco = banco;
        this.numeroConta = numeroConta;
        this.saldo = saldo;
    }

    getNomeCorrentista() {
        return this.nomeCorrentista;
    }

    setNomeCorrentista(nome) {
        this.nomeCorrentista = nome;
    }

    getBanco() {
        return this.banco;
    }

    setBanco(banco) {
        this.banco = banco;
    }

    getNumeroConta() {
        return this.numeroConta;
    }

    setNumeroConta(numero) {
        this.numeroConta = numero;
    }

    getSaldo() {
        return this.saldo;
    }

    setSaldo(saldo) {
        this.saldo = saldo;
    }
}

class ContaCorrenteComSaldoEspecial extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, saldoEspecial) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this.saldoEspecial = saldoEspecial;
    }

    getSaldoEspecial() {
        return this.saldoEspecial;
    }

    setSaldoEspecial(saldoEspecial) {
        this.saldoEspecial = saldoEspecial;
    }
}

class ContaPoupancaComJuros extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, dataVencimento) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this.dataVencimento = dataVencimento;
    }

    getDataVencimento() {
        return this.dataVencimento;
    }

    setDataVencimento(dataVencimento) {
        this.dataVencimento = dataVencimento;
    }
}

// Criando objetos e recebendo dados via prompt
var nome = prompt("Informe o nome do correntista:");
var banco = prompt("Informe o nome do banco:");
var numeroConta = prompt("Informe o número da conta:");
var saldo = parseFloat(prompt("Informe o saldo:"));

var saldoEspecial = parseFloat(prompt("Informe o saldo especial da conta corrente:"));
var contaCorrente = new ContaCorrenteComSaldoEspecial(nome, banco, numeroConta, saldo, saldoEspecial);

var dataVencimento = prompt("Informe a data de vencimento da conta poupança:");
var contaPoupanca = new ContaPoupancaComJuros(nome, banco, numeroConta, saldo, dataVencimento);

alert("Dados da conta corrente com saldo especial:\nNome do Banco: " + contaCorrente.getBanco() + "\nNome do Correntista: " +
        contaCorrente.getNomeCorrentista() + "\nNumero da Conta: " + contaCorrente.getNumeroConta() + "\nSaldo: " + contaCorrente.getSaldo() +
        "\nSaldo Especial: " + contaCorrente.getSaldoEspecial()); 

alert("Dados da conta poupança com juros:\nNome do Banco: " + contaPoupanca.getBanco() + "\nNome do Correntista: " +
contaPoupanca.getNomeCorrentista() + "\nNumero da Conta: " + contaPoupanca.getNumeroConta() + "\nSaldo: " + contaPoupanca.getSaldo() +
"\nData de Vencimento: " + contaPoupanca.getDataVencimento()); 