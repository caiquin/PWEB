var escolha, pc

escolha = prompt("Digite:\n1- para escolher pedra \n2- para escolher papel \n3- para escolher tesoura")

pc = Math.random()

if(pc < 0.33)
    pc = "pedra"
else if(pc < 0.66)
    pc = "papel"
else
    pc = "tesoura"

alert("A escolha do computador foi: " + pc)

if(escolha == "1"){
    if(pc == "pedra")
        alert("Empate")
    else if(pc == "papel")
        alert("O computador foi o vencedor")
    else if(pc =="tesoura")
        alert("Você venceu")
}

if(escolha == "2"){
    if(pc == "papel")
        alert("Empate")
    else if(pc == "tesoura")
        alert("O computador foi o vencedor")
    else if(pc == "pedra")
        alert("Você venceu")
}

if(escolha == "3"){
    if(pc == "tesoura")
        alert("Empate")
    else if(pc =="pedra")
        alert("O computador foi o vencedor")
    else if(pc == "papel")
        alert("Você venceu")
}
