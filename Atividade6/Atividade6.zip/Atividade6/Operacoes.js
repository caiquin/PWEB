var n1,n2;

n1 = prompt("Digite o primeiro numero: ");
n2 = prompt("Digite o segundo numero: ");

var num1 = parseFloat(n1);
var num2 = parseFloat(n2);

alert("Soma: " + (num1 + num2));
alert("Subtração: " + (num1 - num2));
alert("Produto: " + (num1 * num2));
alert("Divisão: " + (num1 / num2));
alert("Resto da divisão: " + (num1 % num2));

