var n1,n2,n3,media;

n1 = prompt("Informe a primeira nota: ");
n2 = prompt("Informe a segunda nota: ");
n3 = prompt("Informe a terceira nota: ");

media = ((parseFloat(n1) + parseFloat(n2) + parseFloat(n3))/3);

alert(media);