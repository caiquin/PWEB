var altura = parseFloat(prompt("Informe a altura"));
var peso = parseFloat(prompt("Informe o peso"));

function calcIMC(altura, peso){
    return (peso / (Math.pow(altura,2)))
}

function Imprime(imc){
    if(imc < 18.5)
        alert("Seu IMC é " + imc.toFixed(2) + " e está em magreza")
    else if(imc >= 18.5)
        alert("Seu IMC é " + imc.toFixed(2) + " e está com peso normal")
    else if(imc >= 25.0)
        alert("Seu IMC é " + imc.toFixed(2) + " e está com sobrepeso")
    else if(imc >= 30.0)
        alert("Seu IMC é " + imc.toFixed(2) + " e está com obesidade")
    else
        alert("Seu IMC é " + imc.toFixed(2) + " e está com obesidade grave")
} 

var imc = calcIMC(altura, peso);

Imprime(imc);