document.addEventListener('DOMContentLoaded', function() {

    if (!window.indexedDB) {
        console.log(`Your browser doesn't support IndexedDB`);
        return;
    }

    const request = indexedDB.open('Task', 6);

    request.onerror = (event) => {
        console.error(`Database error: ${event.target.errorCode}`);
    };


    request.onsuccess = (event) => {
        const db = event.target.result;
        ImprimeTaskP(db); 
    }

    const divContainer = document.querySelector('main');

    function ImprimeTaskP(db){

        const txn = db.transaction('idTask', 'readonly');
        const store = txn.objectStore('idTask');
    
        const getAllRequest = store.getAll();
        getAllRequest.onsuccess = (event) =>{
            const dados = event.target.result;
            const filteredTasks = dados.filter(dado => dado.area == 'Academica');
                filteredTasks.forEach(dado => {
                    const projectCard = document.createElement("div");
                    projectCard.classList.add('projectCard');
                
          
                    const projectTop = document.createElement("div");
                    projectTop.classList.add('projectTop');
                
     
                    const h2Title = document.createElement('h2');
                    h2Title.textContent = dado.titulo;
                    projectTop.appendChild(h2Title);
                
            
                    const projectDots = document.createElement('div');
                    projectDots.classList.add('projectDots');
                    projectDots.textContent = dado.area;
                    projectTop.appendChild(projectDots);
                
                  
                    projectCard.appendChild(projectTop);
                
                 
                    const projectProgress = document.createElement("div");
                    projectProgress.classList.add('projectProgress');
                
           
                    const process = document.createElement('div');
                    process.classList.add('process');
                    const h2Process = document.createElement('h2');
                    h2Process.textContent = dado.progresso;
                    process.appendChild(h2Process);
                    projectProgress.appendChild(process);
                
          
                    const priority = document.createElement('div');
                    priority.classList.add('priority');
                    const h2Priority = document.createElement('h2');
                    h2Priority.textContent = dado.propriedade + " Prioridade";
                    priority.appendChild(h2Priority);
                    projectProgress.appendChild(priority);
                
            
                    projectCard.appendChild(projectProgress);
                
    
                    const groupImg = document.createElement('div');
                    groupImg.classList.add('groupImg');
                
    
                    const h3GroupImg = document.createElement('h3');
                    h3GroupImg.textContent = "Descricao";
                    groupImg.appendChild(h3GroupImg);
                    projectCard.appendChild(groupImg);
                
                    const textarea = document.createElement('textarea');
                    textarea.setAttribute('name', 'desc');
                    textarea.setAttribute('id', 'desc');
                    textarea.textContent = dado.descricao;
                    projectCard.appendChild(textarea);
                
                    const due = document.createElement('div');
                    due.classList.add('due');
                
         
    
                    const h2Due = document.createElement('h2');
                    h2Due.textContent = dado.vencimento;
                    due.appendChild(h2Due);
    
                    const buttonEdit = document.createElement('button');
                    buttonEdit.classList.add('dialog2');
                    buttonEdit.textContent = "Editar";
                    due.appendChild(buttonEdit);
                    
    
                    projectCard.appendChild(due);
    
                    divContainer.appendChild(projectCard);
    
    
                    const dialog = document.createElement('dialog');
                    dialog.classList.add('d2');
    
                    const containerM = document.createElement('div');
                    containerM.classList.add('containerM');
                    const editTitle = document.createElement('h2');
                    editTitle.textContent = 'Editar Tarefa';
                    containerM.appendChild(editTitle);
    
                    const form = document.createElement('form');
    
    
                    const formGroupTitle = document.createElement('div');
                    formGroupTitle.classList.add('form-group');
                    const labelTitle = document.createElement('label');
                    labelTitle.setAttribute('for', 'titulo');
                    labelTitle.textContent = 'Título:';
                    const inputTitle = document.createElement('input');
                    inputTitle.type = 'text';
                    inputTitle.id = 'edittitulo';
                    inputTitle.name = 'edittitulo';
                    inputTitle.value = dado.titulo;
                    formGroupTitle.appendChild(labelTitle);
                    formGroupTitle.appendChild(inputTitle);
    
                    const formGroupPriority = document.createElement('div');
                    formGroupPriority.classList.add('form-group');
                    const labelPriority = document.createElement('label');
                    labelPriority.textContent = 'Prioridade:';
                    const radioGroupPriority = document.createElement('div');
                    radioGroupPriority.classList.add('radio-group');
                    ['alta', 'media', 'baixa'].forEach((value, index) => {
                        const label = document.createElement('label');
                        const input = document.createElement('input');
                        input.type = 'radio';
                        input.name = 'editPrioridade';
                        input.value = value;
                        label.appendChild(input);
                        label.appendChild(document.createTextNode(value.charAt(0).toUpperCase() + value.slice(1)));
                        radioGroupPriority.appendChild(label);
                    });
                    formGroupPriority.appendChild(labelPriority);
                    formGroupPriority.appendChild(radioGroupPriority);
    
                    const formGroupArea = document.createElement('div');
                    formGroupArea.classList.add('form-group');
                    const labelArea = document.createElement('label');
                    labelArea.textContent = 'Área:';
                    const radioGroupArea = document.createElement('div');
                    radioGroupArea.classList.add('radio-group');
                    ['pessoal', 'academica', 'profissional'].forEach((value, index) => {
                        const label = document.createElement('label');
                        const input = document.createElement('input');
                        input.type = 'radio';
                        input.name = 'editArea';
                        input.value = value;
                        label.appendChild(input);
                        label.appendChild(document.createTextNode(value.charAt(0).toUpperCase() + value.slice(1)));
                        radioGroupArea.appendChild(label);
                    });
                    formGroupArea.appendChild(labelArea);
                    formGroupArea.appendChild(radioGroupArea);
    
                    // Descrição
                    const formGroupDescription = document.createElement('div');
                    formGroupDescription.classList.add('form-group');
                    const labelDescription = document.createElement('label');
                    labelDescription.setAttribute('for', 'descricao');
                    labelDescription.textContent = 'Descrição:';
                    const textareaDescription = document.createElement('textarea');
                    textareaDescription.id = 'editdescricao';
                    textareaDescription.name = 'editdescricao';
                    textareaDescription.rows = 5;
                    textareaDescription.textContent = dado.descricao;
                    formGroupDescription.appendChild(labelDescription);
                    formGroupDescription.appendChild(textareaDescription);
    
                    const formGroupDueDate = document.createElement('div');
                    formGroupDueDate.classList.add('form-group');
                    const labelDueDate = document.createElement('label');
                    labelDueDate.setAttribute('for', 'vencimento');
                    labelDueDate.textContent = 'Data de Vencimento:';
                    const inputDueDate = document.createElement('input');
                    inputDueDate.type = 'date';
                    inputDueDate.id = 'editvencimento';
                    inputDueDate.name = 'editvencimento';
                    inputDueDate.value = dado.vencimento;
                    formGroupDueDate.appendChild(labelDueDate);
                    formGroupDueDate.appendChild(inputDueDate);
    
                    const buttons = document.createElement('div');
                    buttons.classList.add('buttons');
                    const deleteButton = document.createElement('button');
                    deleteButton.classList.add('editbutton-red');
                    deleteButton.type = 'button';
                    deleteButton.textContent = 'Excluir';
                    const editDialogButton = document.createElement('button');
                    editDialogButton.classList.add('editbutton-blue');
                    editDialogButton.type = 'button';
                    editDialogButton.textContent = 'Editar';
                    buttons.appendChild(deleteButton);
                    buttons.appendChild(editDialogButton);
    
                    form.appendChild(formGroupTitle);
                    form.appendChild(formGroupPriority);
                    form.appendChild(formGroupArea);
                    form.appendChild(formGroupDescription);
                    form.appendChild(formGroupDueDate);
                    form.appendChild(buttons);
                    containerM.appendChild(form);
                    dialog.appendChild(containerM);
    
                    projectCard.appendChild(dialog);
    
    
                    divContainer.appendChild(projectCard);
    
                    buttonEdit.addEventListener('click', () => {
                        dialog.showModal();
                    });
    
    
                    deleteButton.addEventListener('click', () => {
                        projectCard.remove();
                        dialog.close();
                    });
    
                    editDialogButton.addEventListener('click', () => {
                        const titulo1 = dado.titulo;
                        dado.titulo = inputTitle.value;
                        dado.prioridade = document.querySelector('input[name="editPrioridade"]:checked').value;
                        dado.area = document.querySelector('input[name="editArea"]:checked').value;
                        dado.descricao = textareaDescription.value;
                        dado.vencimento = inputDueDate.value;
                        
                        h2Title.textContent = dado.titulo;
                        projectDots.textContent = dado.area;
                        h2Process.textContent = dado.progresso;
                        h2Priority.textContent = dado.prioridade + " Prioridade";
                        textarea.textContent = dado.descricao;
                        h2Due.textContent = "Due Date: " + dado.vencimento;
    
                        editarTask(db, 6, {
                        titulo: dado.titulo,
                             propriedade: dado.prioridade,
                           area: dado.area,
                           descricao: dado.descricao,
                         progresso: "Concluido",
                         datavencimento: dado.vencimento
                        
                     })
                     modal.close();
                    });
        
        
                });
            
        }
            }
           
});
