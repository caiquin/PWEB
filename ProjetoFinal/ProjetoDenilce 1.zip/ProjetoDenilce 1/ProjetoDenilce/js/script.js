(function () {

    if (!window.indexedDB) {
        console.log(`Your browser doesn't support IndexedDB`);
        return;
    }


    const request = indexedDB.open('Task', 6);


    request.onupgradeneeded = (event) => {
        let db = event.target.result;


        let store = db.createObjectStore('idTask', {
            keypath: 'id',
            autoIncrement: true
        });


        let indexTitulo = store.createIndex('titulo', 'titulo', {
            unique: false
        });
        let indexPropriedade = store.createIndex('prioridade', 'prioridade', {
            unique: false
        });
        let indexArea = store.createIndex('area', 'area', {
            unique: false
        });
        let indexDescricao = store.createIndex('descricao', 'descricao', {
            unique: false
        });
        let indexProgresso = store.createIndex('progresso', 'progresso', {
            unique: false
        })
        let indexDataVencimento = store.createIndex('datavencimento', 'datavencimento', {
            unique: false
        })
    };


    request.onerror = (event) => {
        console.error(`Database error: ${event.target.errorCode}`);
    };


    request.onsuccess = (event) => {
        const db = event.target.result;

    };


    function insertTask(db, task) {

        const txn = db.transaction(['idTask'], 'readwrite');
    

        const store = txn.objectStore(['idTask']);
  
        let query = store.put(task);
    
 
        query.onsuccess = function (event) {
            console.log(query);
        };
  
        query.onerror = function (event) {
            console.log(event.target.errorCode);
        }
    

    }

    // function editarTask(db,id,taskAtualizada) {
    //     return new Promise((resolve, reject) => {
    //         const transaction = db.transaction(['idTask'], 'readwrite');
    //         const store = transaction.objectStore('idTask');

           
    //         const request = store.get(id);

    //         request.onsuccess = function (event) {
    //             const task = event.target.result;

    //             if (task) {
    //                 task.titulo = taskAtualizada.titulo;
    //                 task.prioridade = taskAtualizada.prioridade;
    //                 task.area = taskAtualizada.area;
    //                 task.descricao = taskAtualizada.descricao;
    //                 task.progresso = taskAtualizada.progresso;
    //                 task.datavencimento = taskAtualizada.datavencimento;

    //                 const updateRequest = store.put(task);

    //                 updateRequest.onsuccess = function () {
    //                     resolve('Tarefa atualizada com sucesso.');
    //                 };

    //                 updateRequest.onerror = function (event) {
    //                     reject('Erro ao atualizar a tarefa: ' + event.target.errorCode);
    //                 };
    //             } else {
    //                 reject('Tarefa não encontrada.');
    //             }
    //         };

    //         request.onerror = function (event) {
    //             reject('Erro ao obter a tarefa: ' + event.target.errorCode);
    //         };
    //     });
    // }


    function getTaskIdByTitle(db, title) {
        return new Promise((resolve, reject) => {
            console.log('Título recebido:', title);
            const transaction = db.transaction(['idTask'], 'readonly');
            const store = transaction.objectStore('idTask');
            const index = store.index('titulo');
            
            const request = index.get(title);
    
            request.onsuccess = function(event) {
                const task = event.target.result;
    
                console.log('Tarefa encontrada:', task);
    
                if (task) {
                    resolve(task.titulo);
                } else {
                    reject('Tarefa não encontrada.');
                }
            };
    
            request.onerror = function(event) {
                console.error('Erro ao obter a tarefa:', event.target.errorCode);
                reject('Erro ao obter a tarefa: ' + event.target.errorCode);
            };
    
        });
    }


    function deleteTask(db, id) {
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(['idTask'], 'readwrite');
            const store = transaction.objectStore('idTask');
    
            const deleteRequest = store.delete(id);
    
            deleteRequest.onsuccess = function () {
                resolve('Tarefa deletada com sucesso.');
            };
    
            deleteRequest.onerror = function (event) {
                reject('Erro ao deletar a tarefa: ' + event.target.errorCode);
            };
        });
    }
    function getTaskByTitle(db, title) {
        const txn = db.transaction('idTask', 'readonly');
        const store = txn.objectStore('idTask');


        const index = store.index('titulo');
       
        let query = index.get(title);

 
        query.onsuccess = (event) => {
            return (query.idTask); 
        };

        query.onerror = (event) => {
            console.log(event.target.errorCode);
        }

        txn.oncomplete = function () {
            db.close();
        };
    }
    // function deleteContact(db, titulo) {
    //     // create a new transaction
    //     const txn = db.transaction('idTask', 'readwrite');

    //     // get the Contacts object store
    //     const store = txn.objectStore('idTask');
    //     //
    //     const id = store.index(titulo);
    //     let query = store.delete(id);

    //     // handle the success case
    //     query.onsuccess = function (event) {
    //         console.log(event);
    //     };

    //     // handle the error case
    //     query.onerror = function (event) {
    //         console.log(event.target.errorCode);
    //     }

    //     // close the database once the 
    //     // transaction completes
    //     txn.oncomplete = function () {
    //         db.close();
    //     };

    // }

document.addEventListener('DOMContentLoaded', function() {
    
    if (!window.indexedDB) {
        console.log(`Your browser doesn't support IndexedDB`);
        return;
    }


    const request = indexedDB.open('Task', 6);


    request.onerror = (event) => {
        console.error(`Database error: ${event.target.errorCode}`);
    };


    request.onsuccess = (event) => {
        const db = event.target.result;
        ImprimeTask(db); 

    }

    const button = document.querySelector(".dialog1");
    const modal = document.querySelector("dialog");
    const buttonClose = document.querySelector(".button-red");
    const button2 = document.querySelector(".dialog2");
    const modal2 = document.querySelector(".d2");

    button.onclick = function (){
        modal.showModal();
    }

    buttonClose.onclick = function(){
        modal.close();
        form.reset();
    }





    const titulos = document.getElementById('titulo');
    const descricao = document.getElementById('descricao');
    const vencimento = document.getElementById('vencimento');
    const btnCriar = document.querySelector('.button-blue');

    const divContainer = document.querySelector('main');

    //console.log(titulo, selectedValueP, selectedValueP, descricao, vencimento);
    btnCriar.addEventListener("click", function(){
        const form = document.querySelector('form');
        const radioButtonsP = document.querySelector('input[name="prioridade"]:checked');
        const radioButtonsA = document.querySelector('input[name="area"]:checked');
        let db = request.result;

        const venc = toString(vencimento);
        insertTask(db, {
            titulo: titulos.value,
            propriedade: radioButtonsP.value,
            area: radioButtonsA.value,
            descricao: descricao.value,
            progresso: "Em progresso",
            datavencimento: venc.value
        });

        getTaskIdByTitle(db, titulo.value).then(id => {
            console.log('ID da tarefa:', id);
        }).catch(error => {
            console.error(error);
        });;
        form.reset();
        modal.close();
    
    });

    const btnEdit = document.querySelector('.editbutton-blue');
    const edittitulo = document.getElementById('edittitulo');
    const editdescricao = document.getElementById('editdescricao');
    const editvencimento = document.getElementById('editvencimento');

    // const btnExcluir = document.querySelector('.editbutton-red');

    // btnExcluir.addEventListener("click", function(){
    //         const radioButtonsP = document.querySelector('input[name="editPrioridade"]:checked');
    //         const radioButtonsA = document.querySelector('input[name="editArea"]:checked');

    //         const db = request.result;

    //         deleteContact(db, edittitulo.value);
    // })
    //const progresso = document.getElementById('edit')

    //  btnEdit.addEventListener("click", function(){
    //     const radioButtonsP = document.querySelector('input[name="editPrioridade"]:checked');
    //      const radioButtonsA = document.querySelector('input[name="editArea"]:checked');
    //     let db = request.result;

    //     const updatedTaskData = {
    //         titulo: "dado.titulo",
    //         propriedade: "dado.prioridade",
    //         area: "dado.area",
    //         descricao: "dado.descricao",
    //         progresso: "Concluido",
    //         datavencimento: "dado.vencimento"
    //     }
    //     editTask(db, 23, updatedTaskData)
    //     .then(message => {
    //         console.log(message);
    //     })
    //     .catch(error => {
    //         console.error(error);
    //     });


    //   modal.close();
    //  });

                //     editDialogButton.addEventListener('click', () => {
                //     dado.titulo = inputTitle.value;
                //     dado.prioridade = document.querySelector('input[name="editPrioridade"]:checked').value;
                //     dado.area = document.querySelector('input[name="editArea"]:checked').value;
                //     dado.descricao = textareaDescription.value;
                //     dado.vencimento = inputDueDate.value;
                    
                //     h2Title.textContent = dado.titulo;
                //     projectDots.textContent = dado.area;
                //     h2Process.textContent = dado.progresso;
                //     h2Priority.textContent = dado.prioridade + " Prioridade";
                //     textarea.textContent = dado.descricao;
                //     h2Due.textContent = "Due Date: " + dado.vencimento;
                    
                //     const updatedTaskData = {
                //         titulo: dado.titulo,
                //         propriedade: dado.prioridade,
                //         area: dado.area,
                //         descricao: dado.descricao,
                //         progresso: "Concluido",
                //         datavencimento: dado.vencimento
                //     }
                //     editTask(db, 23, updatedTaskData)
                //     .then(message => {
                //         console.log(message);
                //     })
                //     .catch(error => {
                //         console.error(error);
                //     });


                //     dialog.close();
                // });
    function ImprimeTask(db){

        const txn = db.transaction('idTask', 'readonly');
        const store = txn.objectStore('idTask');

        const getAllRequest = store.getAll();
        getAllRequest.onsuccess = (event) =>{
            const dados = event.target.result;
        
            dados.forEach(dado => {
                const projectCard = document.createElement("div");
                projectCard.classList.add('projectCard');
            
      
                const projectTop = document.createElement("div");
                projectTop.classList.add('projectTop');
            
 
                const h2Title = document.createElement('h2');
                h2Title.textContent = dado.titulo;
                projectTop.appendChild(h2Title);
            
        
                const projectDots = document.createElement('div');
                projectDots.classList.add('projectDots');
                projectDots.textContent = dado.area;
                projectTop.appendChild(projectDots);
            
              
                projectCard.appendChild(projectTop);
            
             
                const projectProgress = document.createElement("div");
                projectProgress.classList.add('projectProgress');
            
       
                const process = document.createElement('div');
                process.classList.add('process');
                const h2Process = document.createElement('h2');
                h2Process.textContent = dado.progresso;
                process.appendChild(h2Process);
                projectProgress.appendChild(process);
            
      
                const priority = document.createElement('div');
                priority.classList.add('priority');
                const h2Priority = document.createElement('h2');
                h2Priority.textContent = dado.propriedade + " Prioridade";
                priority.appendChild(h2Priority);
                projectProgress.appendChild(priority);
            
        
                projectCard.appendChild(projectProgress);
            

                const groupImg = document.createElement('div');
                groupImg.classList.add('groupImg');
            

                const h3GroupImg = document.createElement('h3');
                h3GroupImg.textContent = "Descricao";
                groupImg.appendChild(h3GroupImg);
                projectCard.appendChild(groupImg);
            
                const textarea = document.createElement('textarea');
                textarea.setAttribute('name', 'desc');
                textarea.setAttribute('id', 'desc');
                textarea.textContent = dado.descricao;
                projectCard.appendChild(textarea);
            
                const due = document.createElement('div');
                due.classList.add('due');
            
     

                const h2Due = document.createElement('h2');
                h2Due.textContent = dado.datavencimento;
                due.appendChild(h2Due);

                const buttonEdit = document.createElement('button');
                buttonEdit.classList.add('dialog2');
                buttonEdit.textContent = "Editar";
                due.appendChild(buttonEdit);
                

                projectCard.appendChild(due);

                divContainer.appendChild(projectCard);


                const dialog = document.createElement('dialog');
                dialog.classList.add('d2');

                const containerM = document.createElement('div');
                containerM.classList.add('containerM');
                const editTitle = document.createElement('h2');
                editTitle.textContent = 'Editar Tarefa';
                containerM.appendChild(editTitle);

                const form = document.createElement('form');


                const formGroupTitle = document.createElement('div');
                formGroupTitle.classList.add('form-group');
                const labelTitle = document.createElement('label');
                labelTitle.setAttribute('for', 'titulo');
                labelTitle.textContent = 'Título:';
                const inputTitle = document.createElement('input');
                inputTitle.type = 'text';
                inputTitle.id = 'edittitulo';
                inputTitle.name = 'edittitulo';
                inputTitle.value = dado.titulo;
                formGroupTitle.appendChild(labelTitle);
                formGroupTitle.appendChild(inputTitle);

                const formGroupPriority = document.createElement('div');
                formGroupPriority.classList.add('form-group');
                const labelPriority = document.createElement('label');
                labelPriority.textContent = 'Prioridade:';
                const radioGroupPriority = document.createElement('div');
                radioGroupPriority.classList.add('radio-group');
                ['alta', 'media', 'baixa'].forEach((value, index) => {
                    const label = document.createElement('label');
                    const input = document.createElement('input');
                    input.type = 'radio';
                    input.name = 'editPrioridade';
                    input.value = value;
                    label.appendChild(input);
                    label.appendChild(document.createTextNode(value.charAt(0).toUpperCase() + value.slice(1)));
                    radioGroupPriority.appendChild(label);
                });
                formGroupPriority.appendChild(labelPriority);
                formGroupPriority.appendChild(radioGroupPriority);

                const formGroupArea = document.createElement('div');
                formGroupArea.classList.add('form-group');
                const labelArea = document.createElement('label');
                labelArea.textContent = 'Área:';
                const radioGroupArea = document.createElement('div');
                radioGroupArea.classList.add('radio-group');
                ['pessoal', 'academica', 'profissional'].forEach((value, index) => {
                    const label = document.createElement('label');
                    const input = document.createElement('input');
                    input.type = 'radio';
                    input.name = 'editArea';
                    input.value = value;
                    label.appendChild(input);
                    label.appendChild(document.createTextNode(value.charAt(0).toUpperCase() + value.slice(1)));
                    radioGroupArea.appendChild(label);
                });
                formGroupArea.appendChild(labelArea);
                formGroupArea.appendChild(radioGroupArea);

                // Descrição
                const formGroupDescription = document.createElement('div');
                formGroupDescription.classList.add('form-group');
                const labelDescription = document.createElement('label');
                labelDescription.setAttribute('for', 'descricao');
                labelDescription.textContent = 'Descrição:';
                const textareaDescription = document.createElement('textarea');
                textareaDescription.id = 'editdescricao';
                textareaDescription.name = 'editdescricao';
                textareaDescription.rows = 5;
                textareaDescription.textContent = dado.descricao;
                formGroupDescription.appendChild(labelDescription);
                formGroupDescription.appendChild(textareaDescription);

                const formGroupDueDate = document.createElement('div');
                formGroupDueDate.classList.add('form-group');
                const labelDueDate = document.createElement('label');
                labelDueDate.setAttribute('for', 'vencimento');
                labelDueDate.textContent = 'Data de Vencimento:';
                const inputDueDate = document.createElement('input');
                inputDueDate.type = 'date';
                inputDueDate.id = 'editvencimento';
                inputDueDate.name = 'editvencimento';
                inputDueDate.value = dado.datavencimento;
                formGroupDueDate.appendChild(labelDueDate);
                formGroupDueDate.appendChild(inputDueDate);

                const buttons = document.createElement('div');
                buttons.classList.add('buttons');
                const deleteButton = document.createElement('button');
                deleteButton.classList.add('editbutton-red');
                deleteButton.type = 'button';
                deleteButton.textContent = 'Excluir';
                const editDialogButton = document.createElement('button');
                editDialogButton.classList.add('editbutton-blue');
                editDialogButton.type = 'button';
                editDialogButton.textContent = 'Editar';
                buttons.appendChild(deleteButton);
                buttons.appendChild(editDialogButton);

                form.appendChild(formGroupTitle);
                form.appendChild(formGroupPriority);
                form.appendChild(formGroupArea);
                form.appendChild(formGroupDescription);
                form.appendChild(formGroupDueDate);
                form.appendChild(buttons);
                containerM.appendChild(form);
                dialog.appendChild(containerM);

                projectCard.appendChild(dialog);


                divContainer.appendChild(projectCard);

                buttonEdit.addEventListener('click', () => {
                    dialog.showModal();
                });


                deleteButton.addEventListener('click', () => {
                    projectCard.remove();
                    dialog.close();
                });

                editDialogButton.addEventListener('click', () => {
                    dado.titulo = inputTitle.value;
                    dado.prioridade = document.querySelector('input[name="editPrioridade"]:checked').value;
                    dado.area = document.querySelector('input[name="editArea"]:checked').value;
                    dado.descricao = textareaDescription.value;
                    dado.datavencimento = inputDueDate.value;
                    
                    h2Title.textContent = dado.titulo;
                    projectDots.textContent = dado.area;
                    h2Process.textContent = dado.progresso;
                    h2Priority.textContent = dado.prioridade + " Prioridade";
                    textarea.textContent = dado.descricao;
                    h2Due.textContent = dado.datavencimento;
                    
                    dialog.close();
                });

            });
        }
    }
    function getContactById(db, id) {
        const txn = db.transaction('Contacts', 'readonly');
        const store = txn.objectStore('Contacts');

        let query = store.get(id);

        query.onsuccess = (event) => {
            if (!event.target.result) {
                console.log(`The contact with ${id} not found`);
            } else {
                console.table(event.target.result);
            }
        };

        query.onerror = (event) => {
            console.log(event.target.errorCode);
        }

        txn.oncomplete = function () {
            db.close();
        };
    };
    });



})();


